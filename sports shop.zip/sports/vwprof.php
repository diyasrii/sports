<?php
include "connect.php";
session_start();
$email=$_SESSION['email'];
$id=$_SESSION['r_id'];
?>

          
                
<center>
   
       
            <div class="col-md-4">
                <h1 align="center"><font color="Black"><b>Profile View</b></font></h1>
                <br>
                <table>
                    
                    <?php
                    $result=mysqli_query($con,"select *  from register where email='$email'");

                    if(mysqli_num_rows($result) >0)
                    {

                        while($row1=mysqli_fetch_array($result)){
                            ?>
                                <tr><td><font color=""><b>Name</font></td>
                                <td><font color="yellow"><?php echo $row1[1];?></font></td></tr>

                                 <tr><td><font color=""><b>Lname</font></td>
                                <td><font color="yellow"><?php echo $row1[2];?></font></td></tr>

                                <tr><td><font color=""><b>gender</font></td>
                                <td><font color="yellow"><?php echo $row1[3];?></font></td></tr>

                                 <tr><td><font color=""><b>Mobile</font></td>
                                <td><font color="yellow"><?php echo $row1[4];?></font></td></tr>

                                <tr><td><font color=""><b>Email</font></td>
                                <td><font color="yellow"><?php echo $row1[5];?></font></td></tr>

                                <tr><td><font color=""><b>Address</font></td>
                                <td><font color="yellow"><?php echo $row1[6];?></font></td></tr>

                                <tr><td><font color=""><b>Age</font></td>
                                <td><font color="yellow"><?php echo $row1[7];?></font></td></tr>

                                <tr><td><font color=""><b>Username</font></td>
                                <td><font color="yellow"><?php echo $row1[8];?></font></td></tr>

                                <tr><td><font color=""><b>Password</font></td>
                                <td><font color="yellow"><?php echo $row1[9];?></font></td></tr>

                                <td><a href="update_details.php?id=<?php echo $row1[0];?>"><font color="black"><input type="submit" name="submit" value="EDIT"> </font></td></a>




                            </tr>
                            <?php
                        }
                    }
                    ?>
                </table>
</center>
</div>
</div>

</body>
</html>

