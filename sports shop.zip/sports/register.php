<?php
include 'connect.php';
if(isset($_REQUEST['submit']))
{
    $date = date('Y-m-d');
$ins="INSERT INTO `register`
                    (`fname`,
                    `lname`,
                    `gender`,
                    `mbno`,
                    `email`,
                    `addr`,
                    `age`,
                    `uname`,
                    `password`,
                    `date`)
            VALUES('".$_REQUEST['fname']."',
                   '".$_REQUEST['lname']."',
                   '".$_REQUEST['gender']."',
                   '".$_REQUEST['mbno']."',
                   '".$_REQUEST['eid']."',
                   '".$_REQUEST['addr']."',
                   '".$_REQUEST['age']."',
                   '".$_REQUEST['uname']."',                   
                   '".$_REQUEST['pwd']."',
                   '".$date."')";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);
$ins="INSERT INTO `cvv`
                    (`username`)
            VALUES( '".$_REQUEST['eid']."')";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);



echo "<script type='text/javascript'>alert('Register successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=login.html'>";
}
?>

<script type="text/javascript">
    function Validate() {
          var age = document.getElementById("age");
  var oldEnough = false;
  var result = document.getElementById("answer")
   var password = document.getElementById("pwd").value;
        var confirmPassword = document.getElementById("pwd1").value;

        var name = document.getElementById("nam").value;
        var confirmname = document.getElementById("nam1").value;
  if (parseInt(age.value, 10) >= 18) {
    oldEnough = true;
  } else {
    oldEnough = false;
  }
  if (oldEnough == false) {
   
      alert("You are not old enough");
     return false;
  } else {
    result.innerHTML = "You are old enough."

            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            //return true;

           
            else if (name != confirmname) {
                alert("names do not match.");
                return false;
            }
            return true;
  }
       




    }


</script>