<?php
session_start();

?>
              
                             <h1><center>My Details</center></h1><br>
                             
<style type="text/css">
              th,table,td
              {
              border: 1px solid black;
              
              }
              th
              {
                font-weight: bold;
                
                text-align: center;
              }

                  
            </style> 
                                <!-- AnimateOnScroll Examples -->
                       <table width="100%"  style="">
                           <tr height="80" align="center">
                               <th>FName</th>
                               <th>Lname</th>
                               <th>gender</th>
                               <th>Mobile</th>
                               <th>Email</th>
                               <th>Address</th>
                               <th>Age</th>
                               <th>userid</th>
                               <th>password</th>
                               <th>Registered Date</th>
                               <th>Edit My Profile</th>
                               
                               </tr>

<?php
include "connect.php";
        $result=mysqli_query($con,"select *  from register");
        if(mysqli_num_rows($result) >0)
        {

            while($row1=mysqli_fetch_array($result)){
                
?>
 <tr>
    <tr>
               
                    <td height="40" align="center"><font color=><?php echo $row1[1];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[2];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[3];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[4];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[5];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[6];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[7];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[8];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[9];?></font></td>
                    <td height="40" align="center"><font color=><?php echo $row1[10];?></font></td>
                   <td align="center">
                  <a href='update_details.php?Mode=Edit&id=<?php echo $res->r_id; ?>'><i class="large material-icons">edit</i></a>

                </tr>
                <?php
            }
        }
        ?>             

    
   
   
  
    

    </td>
  </tr>
  

                       </table>              
                                
                                <!-- End AnimateOnScroll Examples -->
                          