<?php
$pid = $_GET['id'];

?>



<div class="container" >
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="row margin-vert-30">
                            <!-- Begin Sidebar Menu -->
                      

                            <!-- End Sidebar Menu -->
                            <div class="col-md-9" style="margin-left: 150px">
                                <h2 style="float: left"> Informations</h2>
    <a href=""> <img src="assets/images/photo/kart.png" height="50" width="100" style="margin-left: 360px;border: 1px solid black;padding:5px ">
    </a>
                       <br><br>          
          <?php
           include "db.php";
           $sel = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * from product2 where P_id='$pid'");
           while($rr = mysqli_fetch_array($sel))
           {
          ?>

                                

                                <blockquote class="primary" style="height: 350px">
                                   
                                   
                                  <div>
                                  <div style="float: left">
                                  <img src="<?php echo $rr[image]?>" height="200" width="200">
                                  </div>
                                  <div style="padding-left: 300px">
                                    Name : <?php echo $rr[p_name]?>
                                    <br>
                                   Price : <?php echo $rr[amount]?>
                                   <br>

                                   Quantity : <?php echo $rr[quantity]?>

                                   <br>

                                   Location : <?php echo $rr[p_location]?>

                                   <br>

                                   Video Link : 
                                   <a href="<?php echo $rr[link]?>"><?php echo $rr[link]?></a>
                                   <br><br><br><br><br><br>
                                 



                                   </div>
                                   <p>
Description : <?php echo $rr[description]?>
  
</p>
                                   <br>
                                   <br>
                                  
                              <br><br>

                                </div>

                                </blockquote>

        <?php  } ?>
                            </div>
                        </div>
                        <!-- === END CONTENT === -->
                        <!-- === BEGIN FOOTER === -->
                    </div>
                   <?php include "footer.php" ?>