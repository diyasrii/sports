<?php
session_start();
?>



<?php
include 'connect.php';
if(isset($_REQUEST['submit']))
{
$names=$_REQUEST['name'];
$pass=$_REQUEST['pwd'];
 $sel="select * from `register` where BINARY uname='$names' and BINARY password='$pass'";
$res=mysqli_query($GLOBALS["___mysqli_ston"], $sel);
$res1=mysqli_fetch_object($res);
if($res1 > 0)
{
echo $_SESSION['name']=$res1->fname;
echo $_SESSION['userid']=$res1->r_id;
echo $_SESSION['email']=$res1->email;



echo "<script type='text/javascript'>alert('Login successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=user.html'>";
}else
{
echo "<script type='text/javascript'>alert('Invalid login');</script>";

}
}
?>
<script type="text/javascript">
    function acc1()
{  
var x=window.prompt("Enter OTP");
var s=parseInt(x);
document.getElementById('r').value=s;
}
</script>
