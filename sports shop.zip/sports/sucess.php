<?php
session_start();
ob_start();
?>

<?php
    
                                        include 'connect.php';
                                        if($_GET){
                                        $bill5 =  $_GET['b1'];
$ss5 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM bill WHERE bill_no=$bill5");
while ($r5=mysqli_fetch_array($ss5)) 
{
  $t50 = $r5['total'];
   // echo $bill5 =  $_GET['b1'];
}
	$var=$_GET['var'];
    $_SESSION['a'][10]=$_GET['var'];
	

$image1=$_SESSION['a'][6];
$image2=$_SESSION['a'][7];
$image3=$_SESSION['a'][8];
$image4=$_SESSION['a'][9];
$image5=$_SESSION['a'][10];
// echo $_SESSION['email'];
$email= $_SESSION['email'];
// echo $image5;
// echo $image4;
// echo $image3;
// echo $image2;
// echo  $image1;
$result="select layer1,layer2,layer3,layer4,layer5 from cvv where username='$email'";
$sql=mysqli_query($con,$result);
// echo $result;
 // echo $bill5 =  $_GET['b1'];
		if (mysqli_num_rows($sql)>0)
		{
			 // echo $bill5 =  $_GET['b1'];
		$row=mysqli_fetch_array($sql);
		// echo 'In database : <br>'.$row[0].'<br>';
		// echo ''.$row[1].'<br>';
		// echo ''.$row[2].'<br>';
		// echo ''.$row[3].'<br>';
		// echo ''.$row[4].'<br><br>My selection :<br>';
		
		// echo ''.$image1.'<br>';
		// echo ''.$image2.'<br>';
		// echo ''.$image3.'<br>';
		// echo ''.$image4.'<br>';
		// echo ''.$image5.'<br>';
		 // echo $bill5 =  $_GET['b1'];
		if($row[0]==$image1 && $row[1]==$image2 && $row[2]==$image3 && $row[3]==$image4 && $row[4]==$image5){
	 echo $bill5 =  $_GET['b1'];
echo "<script type='text/javascript'>alert('suceeded');</script>";
echo "<meta http-equiv='refresh' content='0;url=payments.php?b1=$bill5&tt5=$t50'>";
		}
		else 
		{
			 // echo $bill5 =  $_GET['b1'];
		echo $bill5;
echo "<script type='text/javascript'>alert('error in validation');</script>";
echo "<meta http-equiv='refresh' content='0;url=user.html?b1=$bill5&tt5=$t50'>";
		$_SESSION['selectagain']=1;
		}
		}
		
}


?>

</body>
</html>