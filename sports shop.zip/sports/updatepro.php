


 
                   
                            <div class="col-md-6 col-md-offset-3 col-sm-offset-3" > 
<form class="signup-page" method="post" action="" onsubmit="call()" enctype="multipart/form-data"> 
                                    <div class="signup-header" > 
                                        <h2>UPDATE THINGS</h2> 
                                        <p>Enter Details</p> 
                                    </div> 
                                     <label>Category Name</label>
    

 <select name="category" class="form-control margin-bottom-20" required>
 

<label>Name</label> 
<input class="form-control margin-bottom-20" type="text" name="p_name"    value="<?php echo $r->p_name; ?>" required>  

  

 <label>Image</label> 
<input type="file" name="image" required> 


<br> 



<label>Quantity</label> 
<input class="form-control margin-bottom-20" type="text" 
 name="quantity" value="<?php echo $r->quantity; ?>" required > 


<label>Amount/Price</label> 
<input class="form-control margin-bottom-20" type="text" 
 name="amount" pattern="[0-9]{0,10}" value="<?php echo $r->amount; ?>"> 

<label>company</label> 
<input class="form-control margin-bottom-20" value="<?php echo $r->company; ?>">



  

                                    <br> 
                                    <div class="row"> 
                                        <div class="col-lg-6"> 
                                            <label class="checkbox"> 
                                                
                                                 
                                            </label> 
                                        </div> 

     

                                        <div class="col-lg-2 text-right"> 
        <button class="btn btn-primary" type="submit" name="Update" onclick="return Validate()">UPDATE</button> 
                                        </div> 
                                        <div class="col-lg-2 text-right"> 
        <button class="btn btn-primary" type="reset" name="submit" onclick="return Validate()">CANCEL</button> 
                                        </div> 

     



                                    </div> 

                                </form> 
     
                            </div> 
                            <!-- End Register Box --> 
                        </div> 
                        <!-- === END CONTENT === --> 
                        <!-- === BEGIN FOOTER === --> 
                    </div>

  
                     
<?php 
include ('connect.php'); 

if(isset($_REQUEST['Update'])) 
{ 
     $date = date('Y-m-d'); 
$image=$_FILES['image']['name']; 
$path = "assets/images/photo/$image";             
$file_tmp_name=$_FILES['image']['tmp_name']; 
move_uploaded_file($file_tmp_name,$path); 

 $ins="UPDATE `product2` SET `category_id2`='".$_REQUEST['category']."',`p_name`='".$_REQUEST['p_name']."',`quantity`='".$_REQUEST['quantity']."',`amount`='".$_REQUEST['amount']."',`image`='$path',`date`='$date' WHERE P_id='".$_GET['id']."'";
 echo $ins;
mysqli_query($GLOBALS["___mysqli_ston"], $ins); 


echo "<script type='text/javascript'>alert('updated successfully');</script>"; 
echo "<meta http-equiv='refresh' content='0;url=products.php'>"; 

} 

