-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2021 at 03:00 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spts`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_id` int(11) NOT NULL,
  `bill_no` varchar(100) NOT NULL,
  `bill_name` varchar(100) NOT NULL,
  `cusid` varchar(100) NOT NULL,
  `pro_id` varchar(100) NOT NULL,
  `Pro_qty` varchar(100) NOT NULL,
  `amount1` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'pending',
  `delivery_type` varchar(100) NOT NULL,
  `d_date` varchar(100) NOT NULL,
  `customer_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_id`, `bill_no`, `bill_name`, `cusid`, `pro_id`, `Pro_qty`, `amount1`, `total`, `date`, `status`, `delivery_type`, `d_date`, `customer_type`) VALUES
(1, '1', 'afif', '1', '1', '10', '1000', '1000', '2018-05-28', 'success', 'cash', '2018-05-28', 'normal'),
(2, '2', 'afif', '1', '1', '100', '10000', '10000', '2018-05-28', 'pending', 'online', '', 'paid'),
(3, '3', 'afif', '1', '1', '10', '1000', '1000', '2018-05-28', 'success', 'online', '2018-05-28', 'paid'),
(4, '4', 'afif', '1', '1', '10', '1000', '1990', '2018-05-29', 'pending', 'online', '', 'paid'),
(5, '4', 'afif', '1', '8', '10', '990', '1990', '2018-05-29', 'pending', 'online', '', 'paid'),
(6, '5', 'kk', '3', '1', '3', '300', '300', '2021-02-07 09:02:10', 'pending', 'online', '', 'normal'),
(7, '6', 'kk', '3', '2', '3', '300', '300', '2021-02-07 09:02:12', 'pending', 'online', '', 'normal'),
(8, '7', 'kk', '3', '1', '3', '300', '300', '2021-02-14 05:02:17', 'pending', 'online', '', 'normal'),
(9, '8', '', '', '26', '', '0', '0', '2021-02-24 03:02:23', 'pending', '', '', ''),
(10, '9', '', '', '25', '', '0', '0', '2021-02-24 03:02:27', 'pending', '', '', ''),
(11, '10', '', '', '26', '1', '2000', '2000', '2021/02/24', 'pending', 'online', '', 'normal'),
(12, '10', '', '', '26', '1', '2000', '2000', '2021/02/24', 'pending', 'online', '', 'normal'),
(13, '10', 'dd', '6', '27', '1', '700', '700', '2021-02-28 02:02:06', 'pending', 'online', '', 'normal'),
(14, '10', 'dd', '6', '1', '1', '100', '800', '2021/02/28', 'pending', 'online', '', 'normal'),
(15, '10', 'dd', '6', '27', '1', '700', '800', '2021/02/28', 'pending', 'online', '', 'normal'),
(16, '10', 'dd', '6', '28', '1', '800', '800', '2021/02/28', 'pending', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `bill_address`
--

CREATE TABLE `bill_address` (
  `a_id` int(11) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `cmobile` varchar(100) NOT NULL,
  `caddress` text NOT NULL,
  `caddress2` text NOT NULL,
  `cemail` varchar(100) NOT NULL,
  `bill_no` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_address`
--

INSERT INTO `bill_address` (`a_id`, `cname`, `cmobile`, `caddress`, `caddress2`, `cemail`, `bill_no`, `date`) VALUES
(1, 'afeef', '7356066287', 'lkndfiooikp', 'lkndfiooikp', 'afeefbinqbal@gmail.com', '1', '2018-05-28 14:30:07'),
(2, 'bhg', '7356066287', 'knjkiu', 'knjkiu', 'afeefbinqbal@gmail.com', '3', '2018-05-28 15:03:21'),
(3, 'ad', '9876543210', 'ad', '', 'sda@gmail.com', '4', '2018-05-29 05:17:45');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(5, 'cricket'),
(6, 'football'),
(7, 'Batminton');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `email` varchar(20) NOT NULL,
  `feedback` varchar(20) NOT NULL,
  `fto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`email`, `feedback`, `fto`) VALUES
('admin@gmail.com', 'pls update more prod', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `kart`
--

CREATE TABLE `kart` (
  `k_id` int(11) NOT NULL,
  `c_id` varchar(100) NOT NULL,
  `p_id` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `amt` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kart`
--

INSERT INTO `kart` (`k_id`, `c_id`, `p_id`, `qty`, `amt`, `date`) VALUES
(3, '1', '18', '5', '275', '2018-12-20 07:12:21'),
(4, '1', '18', '1', '55', '2018-12-20 07:12:22'),
(5, '3', '3', '1', '100', '2021-02-07 09:02:12');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`, `usertype`) VALUES
(1, 'admin', 'admin', 'admin'),
(4, 'ds@gmail.com', 'ds', 'user'),
(6, 'dd', 'dd', 'staff');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `userid` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  `discription` varchar(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(20) NOT NULL,
  `name` varchar(60) NOT NULL,
  `cat` varchar(59) NOT NULL,
  `brand` varchar(20) NOT NULL,
  `qty` varchar(11) NOT NULL,
  `amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `cat`, `brand`, `qty`, `amt`) VALUES
(50, 'cricket bat', 'cricket', 'MRF', '1', 1500),
(51, 'gloves', 'cricket', 'Nike', '3', 350);

-- --------------------------------------------------------

--
-- Table structure for table `product2`
--

CREATE TABLE `product2` (
  `P_id` int(11) NOT NULL,
  `category_id2` varchar(100) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `company` varchar(25) NOT NULL,
  `image` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product2`
--

INSERT INTO `product2` (`P_id`, `category_id2`, `p_name`, `quantity`, `amount`, `company`, `image`, `date`) VALUES
(26, 'football', 'football', '0', '2000', 'NIKE', 'assets/images/photo/', '2021-02-23'),
(27, 'cricket', 'crickat ball', '0', '700', 'MRF', 'assets/images/photo/', '2021-02-24'),
(28, 'Tennis', 'Tennis Bat', '0', '800', 'MRF', 'assets/images/photo/', '2021-02-25');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `r_id` int(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `mbno` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `cus_type` varchar(100) NOT NULL DEFAULT 'normal',
  `rent_id` varchar(100) NOT NULL,
  `rent_pwd` varchar(100) NOT NULL,
  `otp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`r_id`, `fname`, `lname`, `gender`, `mbno`, `email`, `addr`, `age`, `uname`, `password`, `date`, `cus_type`, `rent_id`, `rent_pwd`, `otp`) VALUES
(1, 'afif', 'afeef', 'male', '9876543210', 'afeef@gmail.com', 'kndkjf', '21', 'afeef', 'afeef', '2018-05-28', 'normal', '', '', ''),
(3, 'kk', 'd', 'female', '7034140722', 'diya@gmail.com', 'hdsdxs', '23', 'd@gmail.com', 'diyasana', '2021-02-07', 'normal', '', '', ''),
(4, 'dd', 'dd', 'female', '7034140722', 'diya@gmail.com', 'palakkad', '23', 'd@gmail.com', 'diyasrii', '2021-02-13', 'normal', '', '', ''),
(5, 'kailash', 'kailash', 'male', '9995248076', 'kailaashshivam28@gamil.com', 'palakkad', '15', 'k@gamil.com', 'kailaash', '2021-02-13', 'normal', '', '', ''),
(6, 'dd', 'dd', '', '7034140722', 'dd@gmail.com', 'malappuram', '24', 'dd@gmail.com', 'diyadd', '2021-02-14', 'normal', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `bill_address`
--
ALTER TABLE `bill_address`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kart`
--
ALTER TABLE `kart`
  ADD PRIMARY KEY (`k_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product2`
--
ALTER TABLE `product2`
  ADD PRIMARY KEY (`P_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`r_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `bill_address`
--
ALTER TABLE `bill_address`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `kart`
--
ALTER TABLE `kart`
  MODIFY `k_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `product2`
--
ALTER TABLE `product2`
  MODIFY `P_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `r_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
