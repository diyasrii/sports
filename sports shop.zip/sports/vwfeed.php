<?php
session_start();
//$username=$_SESSION['username'];
?>

    <script src="js/responsiveslides.min.js"></script>
</head>
<body>
<style>
body{
    
    background:#48C9B0;
}
<style>


    input[type=submit] {
        width: 50%;
        
        background-color: #f8f8ff;
        color: black;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color:#87cefa;
    }
    table {
        border-collapse: collapse;
        width: 50%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tr:hover{background-color:#b0c4de}
</style>
            </div>
            <!-- top-nav -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <?php
               // include "menu.php";
                ?>
                <div class="clearfix"> </div>
            </div>
        </nav>
    </div>
</div>
<center>
    <!-- //banner-bottom -->
    <div class="about_bot">
        <div class="container">
           <div class="col-md-4 abt-top agileits-w3layouts">
               
            </div>

            <div class="col-md-4">
                <h1 align="center"><font color="black"><b><u>Feedback View</u></b></font></h1>
                <br>
                <table border="2" bgcolor="#F1C40F">
                    <tr>
                        

                        <th><font color="black">FeedBack Details</font></th>


                        <th><font color="black">To</font></th>

                    </tr>
                    <?php
                    include "connect.php";
                    $result=mysqli_query($con,"select *  from feedback");
                    if(mysqli_num_rows($result) >0)
                    {

                        while($row1=mysqli_fetch_array($result)){
                            ?>
                            <tr>
                                
                                <td><font color="black"><?php echo $row1[1];?></font></td>

                                <td><font color="black"><?php echo $row1[2];?></font></td>

                               



                            </tr>
                            <?php
                        }
                    }
                    ?>
                </table>
</center>
</div>
</div>
</div></div></div></div>
<!-- smooth scrolling -->
</body>
</html>

</div>
<!-- //banner -->
<!-- banner-bottom -->
<div class="bottom_wthree">

</div>
</figure>
<div class="clearfix"></div>
</div>

<!-- smooth scrolling -->
</body>
</html>