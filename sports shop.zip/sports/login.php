<?php
require "connect.php";
session_start();
if($con)
{
    if(isset($_POST['submit']))
    {
        $u=$_POST['email'];
        $p=$_POST['password'];
        $strQuery="select * from login where email='$u' and password='$p'";
        $res1=mysqli_query($con,$strQuery);


         if(mysqli_num_rows($res1)>0)
        {
            $row=mysqli_fetch_array($res1);
            $type=$row['usertype'];
            $email=$row['email'];
        
            $lid=$row['id'];
            $_SESSION['id']=$lid;
            $_SESSION['type']=$type;
            $_SESSION['username']=$email;
        
            if($type=='admin')
            {
                header("location:admin.html");
            }
            
            if($type=='user')
            {
                header("location:user.html");
            }
              
           
        }

 
       else
        {
            ?>
        <script type="text/javascript">
    alert("invalid");
    window.location="index.html";
     </script>

       <?php
        }
    }
}
?>