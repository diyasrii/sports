<?php
session_start();
ob_start();
?>

 <div class="container">
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->

                        <div class="row margin-vert-30">
                            <!-- Register Box -->
                            <div class="col-md-7 col-md-offset-3 col-sm-offset-3">
                                <form class="signup-page" action="#" method="post" enctype="multipart/form-data">
                                    <span >Please select  5 corresponding images for your payment:</span>
                                    <div class="signup-header">
                                        <?php
                                        include 'connect.php';
                                        $bill5 =  $_GET['b1'];
                                        echo $bill5;
$ss5 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM bill WHERE bill_no=$bill5");
while ($r5=mysqli_fetch_array($ss5)) 
{
  $t50 = $r5['total'];
}


$ar[0]="A.";
$ar[1]="B.";
$ar[2]="C.";
$ar[3]="D.";
$ar[4]="E.";
$ar[5]="F.";
$ar[6]="G.";
$ar[7]="H.";
$ar[8]="I.";
$ar[9]="J.";
$ar[10]="K.";
$ar[11]="L.";
$ar[12]="M.";
$ar[13]="N.";
$ar[14]="O.";
$ar[15]="P.";
$ar[16]="Q.";
$ar[17]="R.";
$ar[18]="S.";
$ar[19]="T.";


shuffle($ar);

echo '<center>';
for($i=0;$i<=19;$i++)
echo '<img src="images\\'.$ar[$i].'jpg" onclick="changeIt(this)" height="80" width="80"> ';
echo '</center>';


?>
</div>
</form>
</div>
</div>
</div>

<script>
function changeIt(img)
{
var name = img.src;
window.location.href = "sucess.php?b1=<?php echo $bill5?>&tt5=<?php echo $t50?>&var=" + name;
}
</script>


   