<?php
session_start();
$c_id = $_SESSION['userid'];
?>



                    <div class="container">
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="row margin-vert-30">
                            <!-- Begin Sidebar Menu -->
                            
                            <!-- End Sidebar Menu -->
                            <div class="col-md-12">
                             <h1><center>My Details</center></h1><br>
  <?php  include "connect.php"; ?>                             
<style type="text/css">
              th,table,td
              {
              border: 1px solid black;
              
              }
              th
              {
                font-weight: bold;
                
                text-align: center;
              }

                  
            </style> 
                                <!-- AnimateOnScroll Examples -->
                       <table width="100%"  style="">
                           <tr height="80" align="center">
                               <th>Name</th>
                               <th>Mobile</th>
                               <th>Email</th>
                               <th>Address</th>
                              
                               <th>Registered Date</th>
       <th>Edit My Profile</th>
                               </tr>

<?php
include("connect.php");
  //$sqlup="Select * from bill order by bill_id desc";

  $sqlup="Select * from register where r_id='$c_id'";

  $we=mysqli_query($GLOBALS["___mysqli_ston"], $sqlup);
while($res=mysqli_fetch_object($we))
{
?>
 <tr>
    <td height="40" align="center"><?php echo $res->fname; ?></td>
    <td align="center"><?php echo $res->mbno; ?></td>
    <td align="center"><?php echo $res->email; ?></td>
    <td align="center"><?php echo $res->addr; ?></td>
    <td align="center"><?php echo $res->date; ?></td>
  <?php $_SESSION['mail']=$res->email; ?>
   <td align="center">
<a href='update_details.php?Mode=Edit&id=<?php echo $res->r_id; ?>'><i class="large material-icons">edit</i></a>

   
   
  
    

    </td>
  </tr>
  <?php 

 } ?>




                       </table>        
                                

                                
                                
                                <!-- End AnimateOnScroll Examples -->
                            </div>
                        </div>
                        <!-- === END CONTENT === -->
                        <!-- === BEGIN FOOTER === -->
                    </div>
                 