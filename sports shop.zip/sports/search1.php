<?php
session_start();
include "connect.php";

//$Email=$_SESSION['email'];



if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `product` WHERE CONCAT(`id`,`name`,`cat`,`brand`,`qty`,`amt`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `product`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "trolly");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>
<body>
<style>
    input[type=submit] {
        width: 50%;
        background-color: #f8f8ff;
        color: black;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color:#87cefa;
    }
    table {
        border-collapse: collapse;
        width: 80%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tr:hover{background-color:#b0c4de}
</style>


        
        <form action="aj1.php" method="post">
            <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
            <input type="submit" name="search" value="Filter"><br><br>
            
             <table border="2"bgcolor="#F1C40F">
        <tr>
            <th><font color="black"><b>product Name</font></th>
            <th><font color="black">category</font></th>
            
            <th><font color="black">brand</font></th>
            <th><font color="black">quantity </font></th>

            <th><font color="black">price</font></th>
            

            
        </tr>
      <!-- populate table from mysql database -->
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>

                   

                    <td><font color="black"><?php echo $row['name'];?></font></td>

                    <td><font color="black"><?php echo $row['cat'];?></font></td>

                    <td><font color="black"><?php echo $row['brand'];?></font></td>

                    <td><font color="black"><?php echo $row['qty'];?></font></td>

                     <td><font color="black"><?php echo $row['amt'];?></font></td>


                   
                    
                </tr>
                <?php endwhile;?>
            </table>
        </form>
        
    </body>
</html>
