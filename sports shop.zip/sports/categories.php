<?php
session_start();

//$Email=$_SESSION['email'];

  ?>
                   
                            <div class="col-md-12">
                             <h1><center>Category Details</center></h1><br>
                            
<style type="text/css">
              th,table,td
              {
              border: 1px solid black;
              
              }
              th
              {
                font-weight: bold;
                
                text-align: center;
              }

                  
            </style> 
                                <!-- AnimateOnScroll Examples -->
                                <div class="table-responsive">
                       <table width="100%" class="table table-bordered" style="">
                           <tr height="80" align="center">
                             <th>#</th>
                               <th>category ID</th>
                               <th>category name</th>
                               
                               <th>Action</th>
       
                               </tr>

<?php
include "connect.php";
  //$sqlup="Select * from bill order by bill_id desc";


 $sqlup="SELECT * from category ";
   
$n=0;
  $we=mysqli_query($GLOBALS["___mysqli_ston"], $sqlup);
while($res=mysqli_fetch_object($we))
{
    $n++;
?>
 <tr>
    <td height="40" align="center"><?php echo $n; ?></td>
    <td align="center"><?php echo $res->id; ?></td>
      <td align="center"><?php echo $res->category; ?></td>
   <td align="center">


   
    <a href='update_thing.php?Mode=Delete&id=<?php echo $res->id; ?>'><i class="large material-icons">delete</i></a>
       
  
    

    </td>
  </tr>
  <?php 

 } ?>




                       </table>        
                                

                          </div>      
                                
                              
                            </div>
                        </div>
                      
                    </div>