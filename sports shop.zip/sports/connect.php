
	
?>
<?php
error_reporting(0);
$con=($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost", "root", ""));
mysqli_select_db( $con, spts);
?>