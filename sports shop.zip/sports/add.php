<?php
session_start();
?>


                    <div class="container">
                      
                        <div class="row margin-vert-30">
                            <!-- Main Column -->
                            <div class="col-md-9">
                                <!-- Blog Post -->
                                <div class="blog-post">
                                    <!-- Blog Item Header -->
                                    <div class="blog-item-header">
                                        <!-- Date -->
                                        <div class="blog-post-date pull-left">
 <span class="day"><?php echo date('d');?></span>
 <span class="month"><?php echo date('M');?></span>
                                        </div>
                                        
                                        <h2>
                                            <a>
                                                ADD TO CART</a>
                                        </h2>
                                        

                                    </div>
                                   


<?php 
include "connect.php";
$id = $_GET['prod_id'];

$sel = "SELECT * FROM product2 WHERE P_id='$id'";
$ex = mysqli_query($GLOBALS["___mysqli_ston"], $sel);
$res = mysqli_fetch_object($ex);


?>                                    
                                        <div class="blog">
                                        <div class="clearfix"></div>
                                        <div class="blog-post-body row margin-top-15">
                                        <div class="col-md-5">

<img class="pull-left" src="<?php echo $res->image?>" alt="thumb1"
 width="400" height="200">


                                            </div>
<form method="post" action="">                                            
<div class="col-md-7">
<p style="padding-left: 100px">Name &nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $res->p_name;?><br>
                               Price &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo $res->amount;?><br>
                               In Stock : <?php echo $res->quantity;?> <br>



<style type="text/css">
    #id1
    {
  //display: block;
  width: 50%;
  height: 34px;
  padding: 6px 12px;
  font-size: 14px;
  line-height: 1.428571429;
  color: #555555;
  background-color: #ffffff;
  background-image: none;
  border: 1px solid #cccccc;
  border-radius: 5px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  -webkit-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
  -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
  transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    }

</style>
Enter Quantity :
<input type="text" name="qty" id="id1" required><br><br><br>
<input type="submit" name="submit" value="ADD CART" class="btn btn-success">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="shop.php"><input type="button" value="BACK" class="btn btn-success"><a> 
<input type="hidden" name="product" id="id1" value="<?php echo $id?>">
<input type="hidden" name="price" id="id1" value="<?php echo $res->amount?>"> 
    </p>  </form>   
     </div>
       </div>
            <div class="blog-item-footer">
                 <div class="row">
                      <div class="col-md-10">
                               <hr>
                                 </div>
                                                
                                  </div>
                                        </div>
                                    </div>

                                </div>
                               
                            </div>
                          
                        </div>
                        
                    </div>
          


<?php
include ('connect.php');
if(isset($_REQUEST['submit']))
{
  $qty1=$_REQUEST['qty'];
echo $ins="select *from product2 WHERE P_id=$id";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);
$row=mysqli_fetch_array($sql);
if ($row['quantity']<$qty1) {
$pname=$res->p_name;
  $tot=$_REQUEST['price']*$_REQUEST['qty'];
  $date=date('Y-m-d h:m:i');
  $c_id=$_SESSION['userid'];
  echo $ins="INSERT INTO `outofstok`
                   (`c_id`,
                    `p_id`,
                    `qty`,
                    `amt`,
                    `date`)
            VALUES('".$c_id."',
                   '".$pname."',
                   '".$_REQUEST['qty']."',
                   '".$tot."',
                   '".$date."')";
$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);
$i=$_REQUEST['product'];
 echo "<script type='text/javascript'>alert('out of stock');</script>";
echo "<meta http-equiv='refresh' content='0;url=add.php?prod_id=$id'>";

}
else{
$tot = $_REQUEST['price']*$_REQUEST['qty'];

$date = date('Y-m-d h:m:i');
$c_id = $_SESSION['userid'];
echo $ins="INSERT INTO `kart`
                    (`c_id`,
                    `p_id`,
                    `qty`,
                    `amt`,
                    `date`)
            VALUES('".$c_id."',
                   '".$_REQUEST['product']."',
                   '".$_REQUEST['qty']."',
                   '".$tot."',
                   '".$date."')";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);
$i=$_REQUEST['product'];
echo $ins="select *from product2 WHERE P_id=$id";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);
$row=mysqli_fetch_array($sql);

$qty=$row['quantity'];
$qty1=$_REQUEST['qty'];

  $nqty=$qty-$qty1;
  echo $nqty;
 echo $ins="update product2 set quantity='$nqty' WHERE P_id=$id";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);
 echo "<script type='text/javascript'>alert('Added successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=shop.php'>";
}
}
?>