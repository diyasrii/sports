<body>
    <style>
body{
    background:#48C9B0;
}
<style>
    input[type=submit] {
        width: 50%;
        background-color: #f8f8ff;
        color: black;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color:#87cefa;
    }
    table {
        border-collapse: collapse;
        width: 80%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tr:hover{background-color:#b0c4de}
</style>
<?php
session_start();
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
include "connect.php";
 
// Check connection
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $sql = "SELECT * FROM `product` WHERE CONCAT(`id`,`name`,`cat`,`brand`,`qty`,`amt`) LIKE '%".$valueToSearch."%'";
    if($result = mysqli_query($con, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table border=2 bgcolor= #F1C40F >";
            echo "<tr>";
                echo " <th><b>Id</font></th>";
                echo "<th><b>Name</th>";
                echo "<th><b>Category</th>";
                echo "<th><b>Brand</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['cat'] . "</td>";
                echo "<td>" . $row['brand'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Close result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
}
}
 
// Close connection

?>