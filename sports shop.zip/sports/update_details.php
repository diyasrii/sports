<!DOCTYPE html>
<html lang="en">
<head>
<title>Sports Bazaar an E-commerce Online Shopping </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Smart Bazaar Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> 
<link href="css/animate.min.css" rel="stylesheet" type="text/css" media="all" /><!-- animation -->
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all" /> <!-- menu style -->  
<!-- //Custom Theme files -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script> 
<script src="js/jquery-scrolltofixed-min.js" type="text/javascript"></script><!-- fixed nav js -->
<script>
    $(document).ready(function() {

        // Dock the header to the top of the window when scrolled past the banner. This is the default behaviour.

        $('.header-two').scrollToFixed();  
        // previous summary up the page.

        var summaries = $('.summary');
        summaries.each(function(i) {
            var summary = $(summaries[i]);
            var next = summaries[i + 1];

            summary.scrollToFixed({
                marginTop: $('.header-two').outerHeight(true) + 10, 
                zIndex: 999
            });
        });
    });
</script>
<!-- //js --> 
<!-- web-fonts -->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lovers+Quarrel' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Offside' rel='stylesheet' type='text/css'> 
<!-- web-fonts -->  
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event){     
                event.preventDefault();
                $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
            });
        });
</script>
<!-- //end-smooth-scrolling -->
<!-- smooth-scrolling-of-move-up -->
    <script type="text/javascript">
        $(document).ready(function() {
        
            var defaults = {
                containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
            };
            
            $().UItoTop({ easingType: 'easeOutQuart' });
            
        });
    </script>
    <!-- //smooth-scrolling-of-move-up -->
</head>
<body>
    <!-- header -->
    <div class="header">
        <div class="w3ls-header"><!--header-one-->
            <div class="w3ls-header-left">

<?php
session_start();
include_once "connect.php";
if($_GET['Mode']=="Edit")
{
    $id=$_GET['id'];
    // echo  $id;
$sel="select * from register where r_id='".$id."'";
$re=mysqli_query($GLOBALS["___mysqli_ston"], $sel);
$res1=mysqli_fetch_array($re);
}
?>



<div class="login-page">
        <div class="container"> 
                    <div class="container">
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="row margin-vert-30">
                            <!-- Register Box -->
                            <div class="col-md-7 col-md-offset-3 col-sm-offset-2" >
<form class="signup-page" method="post" action="update_details.php" method="post" enctype="multipart/form-data">
                                    <div class="signup-header" >
                                        <h2>UPDATE DETAILS</h2>
                                 <br>
                                    </div>
<label>First Name</label>
<input type="hidden" name="id" value="<?php echo $res1[r_id]?>">
<input class="form-control margin-bottom-20" type="text"
 name="f_name" pattern="[a-zA-Z]{2,30}" required value="<?php echo $res1[fname]; ?>">

<label>Last Name</label>
<input class="form-control margin-bottom-20" type="text"
 name="l_name"  required value="<?php echo $res1[lname]; ?>">

 <label>Gender&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;<?php echo $res1[gender]; ?></label>
<input type="radio" name="gender" <?php if($res1[gender]=="male") {echo "checked";}?> value="male">
&nbsp;&nbsp;Male&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="radio" name="gender" <?php if($res1[gender]=="female") {echo "checked";}?> value="female">
&nbsp;&nbsp;Female&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

 
<br><br>



 <label>Email</label>
<input class="form-control margin-bottom-20" type="text" name="email"  required  value="<?php echo $res1[email]; ?>">
<label> Address</label>
<input class="form-control margin-bottom-20" type="text"
 name="addr"  required placeholder="Enter Address" value="<?php echo $res1[addr]; ?>">


 <label>Age</label>
<input class="form-control margin-bottom-20" type="text" name="age"  required  value="<?php echo $res1[age]; ?>">

 <label>Phone</label>
<input class="form-control margin-bottom-20" type="number" name="phone"  required  value="<?php echo $res1[mbno]; ?>" minlength="0" maxlength="10" pattern="[0-9]{10}">


 <label>User Name</label>
<input class="form-control margin-bottom-20" type="text"
 name="uname"  required placeholder="Enter User name" value="<?php echo $res1[uname]; ?>">

 <label>Password</label>
<input class="form-control margin-bottom-20" type="password"
 name="password"  required placeholder="Enter Password" value="<?php echo $res1[password]; ?>">
 

 

                                    <br>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label class="checkbox">
                                               
                                                
                                            </label>
                                        </div>

                                        <div class="col-lg-2 text-right">
                                            
        <button class="btn btn-primary" type="submit" name="Update" onclick="return Validate()">UPDATE</button>
                                        </div>
                                        <div class="col-lg-2 text-right">
        <button class="btn btn-primary" type="reset" name="submit" onclick="return Validate()">CANCEL</button>

    





                                    </div>
                                </form>
                            </div>
                            <!-- End Register Box -->
                        </div>
                        <!-- === END CONTENT === -->
                        <!-- === BEGIN FOOTER === -->
                    </div>
                     
<?php
include ('connect.php');
session_start();

if(isset($_POST['Update']))
{
$id=$_POST['id'];
$a=$_POST['f_name'];
$b=$_POST['l_name'];
$c=$_POST['gender'];
$d=$_POST['phone'];
$e=$_POST['email'];
$f=$_POST['addr'];
$g=$_POST['age'];
$h=$_POST['uname'];
$i=$_POST['password'];
    

echo $ins="UPDATE `register` SET `fname`='$a',`lname`='$b',`gender`='$c',`mbno`='$d',`email`='$e',`addr`='$f',`age`='$g',`uname`='$h',`password`='$i' WHERE r_id='".$id."'";

mysqli_query($GLOBALS["___mysqli_ston"], $ins);
echo $ins;
echo "<script type='text/javascript'>alert('updated successfully');</script>"; 
echo "<meta http-equiv='refresh' content='0;url=mydetail.php'>"; 


//echo "<meta http-equiv='refresh' content='0;url=my_details.php'>";
}
?>

