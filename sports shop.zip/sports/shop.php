<?php 
 
include "connect.php";
$cate = $_GET['c_id'];
if(isset($cate))
{
$where = "where category_id2='$cate'";
}
?>
<div class="container" >
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="row margin-vert-30">
                            <!-- Begin Sidebar Menu -->
                      

                            <!-- End Sidebar Menu -->
                            <div class="col-md-9">
                                <h2 style="float: left">Purchase Items</h2>
    <a href="kart.php"> <img src="images/kart.png" height="50" width="100" style="margin-left: 360px;border: 1px solid black;padding:5px ">
    </a>
                       <br><br>          
          <?php
           include "connect.php";
           $sel = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * from product2 $where");
           while($rr = mysqli_fetch_array($sel))
           {
          ?>

                                

                                <blockquote class="primary" style="height: 250px">
                                   
                                   
                                  <div>
                                  <div style="float: left">
                                  <img src="<?php echo $rr[image]?>" height="200" width="200">
                                  </div>
                                  <div style="padding-left: 300px">
                                    Name : <?php echo $rr[p_name]?>
                                    <br>
                                   Price : <?php echo $rr[amount]?>
                                  <!-- <br>
                                    Description : <?php echo $rr[description]?>-->
                                    <br>
                                    In Stock : <?php echo $rr[quantity]?> 
                                   <br>
                                   </div>
                                   <br>
                                   <br>
                                   <div style="padding-left: 300px">
                                  <a href="add.php?prod_id=<?php echo $rr[P_id]?>"><button type="button" class="btn btn-success">ADD CART</button></a>
                                   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  <a href="buy.php?prod_id=<?php echo $rr[P_id]?>"><button type="button" class="btn btn-warning">BUY</button></a>
                                </div>
                              <br><br>
<a href="view_info.php?id=<?php echo $rr[P_id]?>" style="padding-left: 50px;color: blue" target='_blank' ><!-- View Info --></a>
                                </div>

                                </blockquote>

        <?php  } ?>
                            </div>
                        </div>
                        <!-- === END CONTENT === -->
                        <!-- === BEGIN FOOTER === -->
                    </div>
                