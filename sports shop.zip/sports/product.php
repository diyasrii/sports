
<?php
include 'connect.php';

if(isset($_REQUEST['submit']))
{
     $date = date('Y-m-d');
$image=$_FILES['image']['name'];
$path = "images/$image";            
$file_tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($file_tmp_name,$path);
echo $ins="INSERT INTO `product2`(`category_id2`,`p_name`,
                    `image`,
                    `quantity`,
                    `amount`,
                    `company`,
                    `date`)
            VALUES('".$_REQUEST['category']."',
                  
                   '".$_REQUEST['p_name']."',                   
                   '".$path."',
                   '".$_REQUEST['quantity']."',
                   '".$_REQUEST['amount']."',
                   '".$_REQUEST['company']."',
                  
                   '".$date."')";
mysqli_query($GLOBALS["___mysqli_ston"], $ins);

echo "<script type='text/javascript'>alert('Added successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=vwproduct.php'>"; 

}
?>