<?php
include ('connect.php');
if(isset($_REQUEST['submit']))
{
    $date = date('Y-m-d');
$ins="INSERT INTO `category`
                    (`category`)

            VALUES('".$_REQUEST['category']."')";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);


echo "<script type='text/javascript'>alert('Added successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=categories.php'>";
}
?>