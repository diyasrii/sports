<?php
session_start();
//$Email=$_SESSION['email'];

    ?>
    <script src="js/responsiveslides.min.js"></script>
</head>
<body>
<style type="text/css">
  th,table,td
              {
              border: 1px solid black;
              
              }
              th
              {
                font-weight: bold;
                
                text-align: center;
              }

                  
</style>
   

<style>
.button {
  background-color:  #008CBA; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}



</style>
<!-- header -->
<!-- //banner-bottom -->
    <div class="about_bot">
        <div class="container">
                <div class="col-md-4 abt-top agileits-w3layouts">
                  <!--  <img src="" alt=" "/>-->
                </div>
                      <h1><center>My Details</center></h1><br>
            <div class="col-md-4">
                           <table width="100%"  style="">
                           <tr height="80" align="center">
                               <th>Category</th>
                               <th>product</th>
                               <th>Quantity</th>
                               <th>Amount</th>
                               <th>company</th>
                               <th>Date</th>
                             
            

            
        </tr>
        <?php
        include "connect.php";
        $result=mysqli_query($con,"select * from product2");
        if(mysqli_num_rows($result) >0)
        {

            while($row1=mysqli_fetch_array($result)){
                ?>
                <tr>
                   

                    <td><font color="black"><?php echo $row1[1];?></font></td>

                    <td><font color="black"><?php echo $row1[2];?></font></td>

                    <td><font color="black"><?php echo $row1[3];?></font></td>

                    <td><font color="black"><?php echo $row1[4];?></font></td>

                    <td><font color="black"><?php echo $row1[5];?></font></td>

                    <td><font color="black"><?php echo $row1[7];?></font></td>

                   
 <td><button class="button"><a href="proupdate.php?id=<?php echo $row1[0]?>&mode=edit"><font color="black">Edit</font></a></td>
</button>
  <td><button class="button"><a href="proupdate.php?id=<?php echo $row1[0]?>&mode=delete" onclick="return confirm('Do You Really Want To Delete?');"><font color="black">Delete</font></a></td></button>
 





 <!--<td><a href="product.html?id=<?php// echo $row1[0]?>&mode=edit"><font color="blue"> Add&nbsp;</font></td>-->
   
 
</tr>

            
                <?php
            }
        }
        ?>
    </table>
     <button class="button"><a href="product.html">Add</button>   
    </center>
</div>
</div>
</div></div></div></div>
<!-- smooth scrolling -->
</body>
</html>

</div>
<!-- //banner -->
<!-- banner-bottom -->
<div class="bottom_wthree">

</div>
</figure>
<div class="clearfix"></div>
</div>

<!-- smooth scrolling -->
</body>
</html>