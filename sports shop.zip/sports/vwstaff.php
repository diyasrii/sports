<?php
session_start();
//$Email=$_SESSION['email'];

    ?>
    <script src="js/responsiveslides.min.js"></script>
</head>
<body>
<style>
body{
    background:#48C9B0;
}
<style>


    input[type=submit] {
        width: 50%;
        
        background-color: #f8f8ff;
        color: black;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color:#87cefa;
    }
    table {
        border-collapse: collapse;
        width: 70%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tr:hover{background-color:#b0c4de}
</style>

<style>
.button {
  background-color:  #008CBA; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
<!-- header -->
<!-- //banner-bottom -->
    <div class="about_bot">
        <div class="container">
                <div class="col-md-4 abt-top agileits-w3layouts">
                  <!--  <img src="" alt=" "/>-->
                </div>

            <div class="col-md-4">
    <h1 align="center"><font color="black"><b>View staff</b></font></h1>
    <br>
    <table border="2"bgcolor="#F1C40F">
        <tr>
            <th><font color="black"><b> Name</font></th>
            <th><font color="black">email</font></th>
            
            <th><font color="black">password</font></th>
          
            

            
        </tr>
        <?php
        include "connect.php";
        $result=mysqli_query($con,"select * from staff");
        if(mysqli_num_rows($result) >0)
        {

            while($row1=mysqli_fetch_array($result)){
                ?>
                <tr>
                   

                    <td><font color="black"><?php echo $row1[0];?></font></td>

                    <td><font color="black"><?php echo $row1[1];?></font></td>

                    <td><font color="black"><?php echo $row1[2];?></font></td>

                   
                   

                   
 




 <!--<td><a href="product.html?id=<?php// echo $row1[0]?>&mode=edit"><font color="blue"> Add&nbsp;</font></td>-->
   
 
</tr>

            
                <?php
            }
        }
        ?>
    </table>
     <button class="button"><a href="staff.html">Add</button>   
    </center>
</div>
</div>
</div></div></div></div>
<!-- smooth scrolling -->
</body>
</html>

</div>
<!-- //banner -->
<!-- banner-bottom -->
<div class="bottom_wthree">

</div>
</figure>
<div class="clearfix"></div>
</div>

<!-- smooth scrolling -->
</body>
</html>