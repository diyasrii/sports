<?php
session_start();
include 'connect.php';

$bill5 =  $_GET['b'];
$ss5 = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM bill WHERE bill_no=$bill5");
while ($r5=mysqli_fetch_array($ss5)) 
{
  $t50 = $r5['total'];
}
?>


                    <div class="container">
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="container">
                            <div class="row margin-vert-30">
                                <!-- Login Box -->

                                <div class="col-md-6 col-md-offset-3 col-sm-offset-3">
  <form class="login-page"  align="" onsubmit="acc()" method="post" action="">
                                        <div class="login-header margin-bottom-30">
                                            <h2>Select Payment Option</h2>
                                        </div>
                                        <div class="input-group margin-bottom-20">


   <input  type="hidden" name="billno" value="<?php echo $_GET['b']?>">
   
     <input   type="radio" name="payment" value="cash" required>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cash On Delivery
                                        </div>
                                        <div class="input-group margin-bottom-20">
                                            
<input   type="radio" name="payment" value="online" required>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Online Payment
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="checkbox">
                                                   
                                            </div>
                                            <div class="col-md-3">
<button class="btn btn-primary pull-right" type="submit" name="submit"
 >Proceed</button>
                                            </div>

    <div class="col-md-3">
                                                
                                            </div>
                                        </div>
                                        <hr>
                                        <h4></h4>
                                        <p>
                                            <a class="color-green" href="#"></a></p>
                                    </form>
                                </div>
                                <!-- End Login Box -->
                            </div>
                        </div>
                        <!-- === END CONTENT === -->
                        <!-- === BEGIN FOOTER === -->
                    </div>
                 


<?php
include 'connect.php';
if(isset($_REQUEST['submit']))
{
$billno2=$_REQUEST['billno'];
$type=$_REQUEST['payment'];


echo  $up="update bill set delivery_type='$type',
                          customer_type='normal'
                           WHERE bill_no='$billno2'";
$res=mysqli_query($GLOBALS["___mysqli_ston"], $up);

if($type == 'cash')
{
echo "<script type='text/javascript'>alert('Successfully Placed');</script>";
echo "<meta http-equiv='refresh' content='0;url=address.php?b1=$billno2'>";
}else
{
    echo "<script type='text/javascript'>alert('Successfully Placed');</script>";
echo "<meta http-equiv='refresh' content='0;url=lay.php?b1=$billno2&tt5=$t50'>";
}

}

?>

