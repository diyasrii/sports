<?php
session_start();
?>
                    <div class="container">
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="row margin-vert-30">
                            <!-- Begin Sidebar Menu -->
                            
                            <!-- End Sidebar Menu -->
                            <div class="col-md-12">
                             <h1><center>My Orders</center></h1><br>
  <?php  include "connect.php"; ?>                             
<style type="text/css">
              th,table,td
              {
              border: 1px solid black;
              
              }
              th
              {
                font-weight: bold;
                
                text-align: center;
              }

                  
            </style> 
                     <div class="table-responsive">           <!-- AnimateOnScroll Examples -->
                       <table class="table table-bordered">
                           <tr height="80" align="center">

                               <th>S.No</th>
                               <th>Bill.No</th>
                               <th>C.Name</th>
                               <th>Mail</th>
                               <th>D.Address</th>
                               <th>Phone</th> 
                               <th>Material</th>  
                               <th>Qty</th>
                               <th>Amount</th>
                               <th>Date</th>
                               <th>D.Date</th>
                               <th>Status</th>
                               </tr>

<?php

include("connect.php");

$id=$_SESSION['email'];
 // echo $id;
  //$sqlup="Select * from bill order by bill_id desc";

  //$sqlup="Select * from bill left join bill_address on bill.bill_no=bill_address.bill_no left join product on bill.pro_id=product.P_id left join register on register.r_id=bill.cusid
  //WHERE register.cus_type='rent' order by bill.bill_id asc";

  $sqlup="Select * from bill left join bill_address on bill.bill_no=bill_address.bill_no left join product2 on bill.pro_id=product2.P_id left join register on register.r_id=bill.cusid
  WHERE register.cus_type='normal' and register.email=bill_address.cemail and bill_address.cemail='$id' order by bill.bill_id asc  ";
 // echo $sqlup;
  $we=mysqli_query($GLOBALS["___mysqli_ston"], $sqlup);
while($res=mysqli_fetch_object($we))
{
?>
 <tr>
     <td align="center"><?php echo $res->bill_id; ?></td>
    <td align="center"><?php echo $res->bill_no; ?></td>
    <td align="center"><?php echo $res->bill_name; ?></td>
    <td align="center"><?php echo $res->cemail; ?></td>
    <td align="center"><?php echo $res->caddress; ?></td>
    <td align="center"><?php echo $res->cmobile; ?></td>
    <td align="center"><?php echo $res->p_name; ?></td>
    <td align="center"><?php echo $res->Pro_qty; ?></td>
    <td align="center"><?php echo $res->amount1; ?></td>
    <td align="center"><?php echo $res->date; ?></td>

    <td align="center"><?php echo $res->d_date; ?></td>


    <td align="center">
    <?php
     if($res->status=='pending')
     {
        echo $res->status;
      
     }

     else
     {
       ?>  
  
<?php
echo $res->status;
}
}
?>
         </td>
 </tr>
</table>       
</div>
  <form class="signup-page" method="post" action="generate_pdf.php" onsubmit="call()">
                                    
                                 
<label>Enter bill no to get invoice</label>
<input class="form-control margin-bottom-20" type="text"
 name="s" required>





                                    <hr>
                                    <div class="row">
                                        <div class="col-lg-8">
                                            
                                        </div>
                                        <div class="col-lg-4 text-right">
        <button class="btn btn-primary" type="submit" name="submit" onclick="return Validate()">Submit</button>
                                        </div>
                                    </div>
                                </form>
                              
                              <?php
                            
                              
                      ?> 
      
                                <!-- End AnimateOnScroll Examples -->
                            </div>
                        </div>
                        <!-- === END CONTENT === -->
                        <!-- === BEGIN FOOTER === -->

                    </div>
                   
                     <?php include "footer.php" ; ?>