<?php
include("connect.php");

session_start();
echo $name=$_SESSION['name'];
$c_id = $_SESSION['userid'];
echo $email=$_SESSION['email'];
  //$sqlup="Select * from bill order by bill_id desc";

 // $sqlup="Select * from register where r_id='$c_id'";

  
     

$s="SELECT * FROM bill_address where cname='$name'";
$sel = mysqli_query($GLOBALS["___mysqli_ston"], $s);
while($r=mysqli_fetch_object($sel))
{



?>


                    <div class="container">
                        <!-- === END HEADER === -->
                        <!-- === BEGIN CONTENT === -->
                        <div class="row margin-vert-30">
                            <!-- Register Box -->
                            <div class="col-md-6 col-md-offset-3 col-sm-offset-3">
<form class="signup-page" method="post" action="" onsubmit="call()">
                                    <div class="signup-header">
                                        <h2>Enter Your Address For Delivery</h2>
                                        
                                    </div>
<label>Name</label>
<input class="form-control margin-bottom-20" type="text"
 name="cname" value="<?php echo $name?>" required>

 <input class="form-control margin-bottom-20" type="hidden"
 name="bill_no" value="<?php echo $_GET['b1'];?>" required>


<label>Mobile</label>
<input class="form-control margin-bottom-20" type="text"
 name="cmobile" pattern="[0-9]{10}" required>

<label>Delivery Address</label>
<textarea name="caddress" class="form-control margin-bottom-20" id="addr1" ><?php echo $r->caddress; ?></textarea>

<label>Confirm Delivery Address</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="" 
onclick="call()" id="check1">&nbsp;&nbsp;Same Address
<textarea name="caddress2" class="form-control margin-bottom-20" id="addr2" ></textarea>




            <label>Email 
                                        <span class="color-red">*</span>
                                    </label>
<input class="form-control margin-bottom-20" type="email" value="<?php  echo $r->cemail;?>" name="cemail">
                                    


                                    <hr>
                                    <div class="row">
                                        <div class="col-lg-8">
                                            
                                        </div>
                                        <div class="col-lg-4 text-right">
        <button class="btn btn-primary" type="submit" name="submit" onclick="return Validate()">Submit</button>
                                        </div>
                                    </div>
                    


                                </form>
                            </div>
                        </div>
                    </div>
                    
                            <!-- End Register Box -->
                            <?php
                        }
                        ?>
                       
                    
<?php
include ('connect.php');
if(isset($_REQUEST['submit']))
{
   $date = date("Y/m/d");
$ins="INSERT INTO `bill_address`
                    (`cname`,
                    `cmobile`,
                    `caddress`,
                    `caddress2`,
                    `cemail`,
                    `bill_no`)
            VALUES('".$_REQUEST['cname']."',
                   '".$_REQUEST['cmobile']."',
                   '".$_REQUEST['caddress']."',
                   '".$_REQUEST['caddress2']."',
                   '".$_REQUEST['cemail']."',
                   '".$_REQUEST['bill_no']."')";

$sql=mysqli_query($GLOBALS["___mysqli_ston"], $ins);

echo $mail1 = $_REQUEST['cemail'];
if($mail1!=$_SESSION['email'])
{
echo $mail2 = $_SESSION['email'];
}
//$sel = mysql_query("SELECT * FROM bill WHERE bill_no='".$_REQUEST['bill_no']."'");

$sqlup="Select * from bill left join product2 on bill.pro_id=product2.P_id
   WHERE bill.bill_no='".$_REQUEST['bill_no']."'";

$sel = mysqli_query($GLOBALS["___mysqli_ston"], $sqlup);

$bodyContent="<table border='1' cellspacing='0' cellpadding='10'>

                <tr>
                <td>Bill No</td>
                <td>Product </td>
                <td>Qty</td>
                <td>Amount</td>

                </tr>";
while ($rr=mysqli_fetch_array($sel)) 
{
    $bodyContent .= "
                 <tr>    
                            <td>$rr[bill_no]</td>
                        
                             
                        
                           
                            <td>$rr[p_name]</td>
                        
                      
                            <td>$rr[Pro_qty]</td>
                         
                       
                            
                            <td>$rr[amount1]</td>
                       
                 </tr>
                 ";
$t5 = $rr['total'];

}

$adr = $_REQUEST['caddress'];
$bodyContent .= "
<tr>
 <td colspan='2'>&nbsp;</td>
 <td>Total</td>
 <td>$t5</td>
</tr>
</table>"."<br>DELIVERY ADDRESS : <br>".$adr;


require 'PHPMailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

$mail->isSMTP();                            // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';             // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                     // Enable SMTP authentication
$mail->Username = 'dummyeshoppy123@gmail.com';          // SMTP username
$mail->Password = 'google143'; // SMTP password
$mail->SMTPSecure = 'tls';                  // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                          // TCP port to connect to

$mail->setFrom('info@example.com', 'groceery shoppy');
$mail->addReplyTo('info@example.com', 'grocerry shoppy');
$mail->addAddress($mail1);   // Add a recipient


$mail->isHTML(true);  // Set email format to HTML
$sqlup="Select * from bill left join product2 on bill.pro_id=product2.P_id
   WHERE bill.bill_no='".$_REQUEST['bill_no']."'";

$sel = mysqli_query($GLOBALS["___mysqli_ston"], $sqlup);
$rr=mysqli_fetch_array($sel);
$bodyContent = "
<table border='2' cellspacing='0' cellpadding='10'>
<tr>
<th>order no : </th>
<th>Order date : </th>
<th>order amount:</th>
</tr>
<tr>
<td>
$rr[bill_no]</td>

<td>$rr[date]</td>

<td>$rr[amount1]</td>
</tr>
</table>
<table cellspacing='0' cellpadding='10'>
<tr>
<td>Billing Details</td>
</tr>

                 <tr>
                     <td><table cellspacing='0' cellpadding='50'>
                         <tr>
                            <th>Customer : </th>
                            <td>$_REQUEST[cname]</td>
                             <td>| </td>
                            <td>$_REQUEST[cemail]</td>
                             <td>|</td>
                            <td>$_REQUEST[cmobile]</td>
                         </tr>
                    
                              
                         <tr>
                            <th>Address : </th>
                            <td>$_REQUEST[caddress]</td>
                          
                         </tr>
                         
                             
                       <tr>    <th>Pay mode </th> 
                            <td>$rr[delivery_type]</td>
                        
                             </tr>
                        
                      </td>
                 </tr>
                 </table>
";

$mail->Subject = '';
$mail->Body    = $bodyContent;

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';

}




echo "<script type='text/javascript'>alert('Ordered successfully..Thank You');</script>";










}
?>
<script type="text/javascript">
    function call() {
        if(document.getElementById('check1').checked == true)
        {
        document.getElementById('addr2').value = document.getElementById('addr1').value;

      
        }
        else
        {
            document.getElementById('addr2').value = "";
        }
      }
</script>