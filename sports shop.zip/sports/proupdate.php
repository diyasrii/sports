<?php
session_start();
$email=$_SESSION['email'];
//$username=$_SESSION['username'];
if($_GET['mode']=='delete'){
    $id=$_GET['id'];
    echo $_GET['mode'];
    echo $id;
     include 'connect.php';
    $sql="DELETE FROM `register` WHERE r_id=$r_id";
$result=mysqli_query($con,$sql);
 ?>
    <script type="text/javascript">
        alert("deleted successfully");
            window.location="vwproduct.php";
        </script>
        <?php
}
else{
?>

<style>
body{
    background:#48C9B0;
}
<style>
 <script src="js/responsiveslides.min.js"></script>
</head>
<body>
<style>
    input[type=submit] {
        width: 50%;
        background-color: #f8f8ff;
        color: black;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color:#87cefa;
    }
    table {
        border-collapse: collapse;
        width: 80%;
    }

    th, td {
        padding: 11px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    tr:hover{background-color:#b0c4de}
</style>

            <!-- top-nav -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
               <?php
               // include "menu.php";
                ?>
                <div class="clearfix"> </div>
            </div>
        </nav>
    </div>
</div>
<center>
    <!-- //banner-bottom -->
    <div class="about_bot">
        <div class="container">
            <div class="col-md-4 ">
              <!--  <img src="images/" alt=" "/>-->
            </div>
<div class="col-md-2"></div>
            <div class="col-md-6">
                <h1 align="center"><font color="black"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;product update</b></font></h1>
                <br>
                <form action="vwproduct.php" method="POST">
                    <table>

                        <?php
                        include 'connect.php';

                        $r_id=$_GET['r_id'];

// Retrieve data from database
                        $sql="SELECT * FROM product2 WHERE r_id='$r_id'";
                        $result=mysqli_query($con,$sql);
                        $rows=mysqli_fetch_array($result);
                        ?>
                        <div class="col-sm-2">
                            <div class="inputContainer">
                                
                        <tr><input name="id" type="hidden" id="id" class="form-control" value="<?php echo $rows['id']; ?>">
                        </tr>
                        <tr>
                        <td>product name:</td>

                        <td>
                            <input name="name"  style="width:350px;" type="text" class="form-control" value="<?php echo $rows['name']; ?>"></br>
                            
                        </td>
                        </tr>
                        <tr>
                        <td>category:</td>

                        <td>
                            <input name="category" style="width:350px;" type="text" class="form-control" value="<?php echo $rows['cat']; ?>"></br>
                        </td>
                            </tr>
                        <tr>
                        <td>Brand</td>

                        <td>
                            <input name="company" style="width:350px;" type="text" class="form-control" value="<?php echo $rows['brand']; ?>"><br>
                        </td></tr>
                     
                        <tr>
                        <td>Quantity:</td>

                        <td>
                            <input name="quantity" style="width:350px;" type="text" class="form-control" value="<?php echo $rows['qty']; ?>"><br>
                        </td></tr>
                        <tr>
                        <td>Price:</td>

                        <td>
                            <input name="amount" style="width:350px;" type="text"  class="form-control"value="<?php echo $rows['amt']; ?>"><br>
                        </td></tr>
                        <tr>
                            
                        <tr>
                       
                            <td>
                       
                         <input type="submit" id="view" name="view" value="Update"></td>
                  
                   
               

</center>
            </div>

</div>
</div>
</div>
</div>
</div></div></div></div>
<!-- smooth scrolling -->

</body>
</html>
<?php
}
?>
</div>
<!-- //banner -->
<!-- banner-bottom -->
<div class="bottom_wthree">

</div>
</figure>
<div class="clearfix"></div>
</div>

<!-- smooth scrolling -->
</body>
</html>