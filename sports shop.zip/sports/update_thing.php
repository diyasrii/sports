<?php 
session_start(); 
include_once "connect.php"; 
if($_GET) 
{ 
$mode=$_GET['Mode']; 

if ($mode=='Delete') { 
    include_once "db.php"; 
     $del="delete from category where id='".$_GET['id']."'"; 
    
$res=mysqli_query($GLOBALS["___mysqli_ston"], $del); 
echo "<script type='text/javascript'>alert('deleted successfully');</script>"; 
echo "<meta http-equiv='refresh' content='0;url=categories.php'>"; 
} 
if ($mode=='Edit') { 
    

?> 


<?php  
 include "header2.php";?> 
                    <div class="container"> 
                        <!-- === END HEADER === --> 
                        <!-- === BEGIN CONTENT === --> 
                        <div class="row margin-vert-30"> 
                            <!-- Register Box --> 
                            <div class="col-md-6 col-md-offset-3 col-sm-offset-3" > 
<form class="signup-page" method="post" action="" onsubmit="call()" enctype="multipart/form-data"> 
                                    <div class="signup-header" > 
                                        <h2>UPDATE THINGS</h2> 
                                        <p>Enter Details</p> 
                                    </div> 
  <label>Categrory name</label>
<?php
$sel = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * FROM category");

$r = mysqli_fetch_array($sel);

?>

   <input class="form-control margin-bottom-20" type="text" name="p_name"    value="<?php echo $r[category]; ?>" required>  

    



                                        <div class="col-lg-2 text-right"> 
        <button class="btn btn-primary" type="submit" name="Update" onclick="return Validate()">UPDATE</button> 
                                        </div> 
                                        <div class="col-lg-2 text-right"> 
        <button class="btn btn-primary" type="reset" name="submit" onclick="return Validate()">CANCEL</button> 
                                        </div> 

     




                                    </div> 
                                </form> 
                            </div> 
                            <!-- End Register Box --> 
                        </div> 
                        <!-- === END CONTENT === --> 
                        <!-- === BEGIN FOOTER === --> 
                    </div> 
                     <?php  include "footer.php";?> 
<?php 
include 'connect.php'; 

if(isset($_REQUEST['submit'])) 
{ 
     $date = date('Y-m-d'); 
$image=$_FILES['image']['name']; 
$path = "assets/images/photo/$image";             
$file_tmp_name=$_FILES['image']['tmp_name']; 
move_uploaded_file($file_tmp_name,$path); 

 $ins="UPDATE `category` SET `category`='".$_REQUEST['p_name']."'  WHERE id='".$_GET['id']."'";
 echo $ins;
mysqli_query($GLOBALS["___mysqli_ston"], $ins); 



} 
} 
} 